using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Windows.Forms;
// Avoid ambiguous Timer reference:
using Timer = System.Windows.Forms.Timer;

namespace SnakeGame
{
    public partial class Form1 : Form
    {
        private const int GridWidth = 20;    // columns
        private const int GridHeight = 20;   // rows
        private const int CellSize = 20;     // pixels per cell (GamePanel size = Grid * CellSize)
        private readonly Random rand = new Random();

        private LinkedList<Point> snake;     // head = First
        private Point food;
        private Direction direction;
        private bool nextMoveIsDirectionLocked; // prevent immediate reverse within one tick
        private bool growingThisTick;

        private int score = 0;
        private int highScore = 0;

        // Level & speed
        private int level = 3; // **starts at 3 as requested**
        private int baseInterval = 250; // baseline ms for level 1; will be adjusted by level
        private int currentInterval => Math.Max(40, baseInterval - (level - 1) * 25); // don't go below 40ms
        private int temporarySpeedModifierTicks = 0; // ticks remaining for temporary speed effect (fast/slow food)

        // Game state enum
        private enum GameState { StartScreen, Running, Paused, GameOver }
        private GameState state = GameState.StartScreen;

        // Food types
        private enum FoodType { Normal, FastFood, SlowFood, BonusFood }
        private FoodType currentFoodType = FoodType.Normal;

        // Colors (configurable)
        private Color snakeHeadColor = Color.LimeGreen;
        private Color snakeBodyColor = Color.Green;
        private Color foodNormalColor = Color.Red;
        private Color foodBonusColor = Color.Gold;
        private Color backgroundColor = Color.Black;

        // If you want to adjust speed, change interval. Lower = faster.

        public Form1()
        {
            InitializeComponent();

            // Set sizes according to grid
            GamePanel.Width = GridWidth * CellSize;
            GamePanel.Height = GridHeight * CellSize;

            lblScore.Text = "Score: 0";
            lblHighScore.Text = "High Score: 0";
            lblMessage.Text = $"Press Start to begin\nArrow keys to move\nStarting Level: {level}";

            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            gameTimer.Tick += gameTimer_Tick;
            GamePanel.Paint += GamePanel_Paint;

            btnApplySettings.Click += BtnApplySettings_Click;
            btnChooseSnakeColor.Click += BtnChooseSnakeColor_Click;
            btnChooseBgColor.Click += BtnChooseBgColor_Click;
            btnSettings.Click += (s, e) => { panelSettings.Visible = !panelSettings.Visible; };
            panelSettings.Visible = false;

            // Make keyboard work everywhere
            HookAllControls(this);
        }




        private void HookAllControls(Control control)
        {
            control.KeyDown += Form1_KeyDown;
            control.PreviewKeyDown += (sender, e) =>
            {
                if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down ||
                    e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
                {
                    e.IsInputKey = true;
                }
            };

            foreach (Control child in control.Controls)
            {
                HookAllControls(child);
            }
        }
     
        #region Game control method

        private void StartGame()
        {
            // Reset state
            snake = new LinkedList<Point>();
            // Start with three segments horizontally centered, moving right
            int startX = GridWidth / 2;
            int startY = GridHeight / 2;
            snake.AddFirst(new Point(startX, startY));          // head
            snake.AddLast(new Point(startX - 1, startY));       // body
            snake.AddLast(new Point(startX - 2, startY));       // tail

            direction = Direction.Right;
            nextMoveIsDirectionLocked = false;
            growingThisTick = false;
            score = 0;
            lblScore.Text = "Score: 0";
            lblMessage.Text = "";
            state = GameState.Running;

            // Place initial food
            PlaceFood();

            // Timer interval depends on level
            baseInterval = 250; // baseline for level scaling; you can change this
            gameTimer.Interval = currentInterval;
            gameTimer.Start();
          //  btnPause.Text = "Pause";

            // ensure form has focus
            this.Focus();
        }

        private void PauseGame()
        {
            if (state == GameState.Running)
            {
                gameTimer.Stop();
                state = GameState.Paused;
                lblMessage.Text = "Paused";
                btnPause.Text = "Resume";
            }
            else if (state == GameState.Paused)
            {
                gameTimer.Start();
                state = GameState.Running;
                lblMessage.Text = "";
                btnPause.Text = "Pause";
            }
        }

        private void EndGame()
        {
            gameTimer.Stop();
            state = GameState.GameOver;
            if (score > highScore) highScore = score;
            lblHighScore.Text = $"High Score: {highScore}";
            lblMessage.Text = $"Game Over\nScore: {score}\nLevel: {level}\nPress Start to restart";
            btnPause.Text = "Pause";

            // game over sound
            SystemSounds.Hand.Play();
        }
        #endregion

        #region Game tick and movement
        private void gameTimer_Tick(object sender, EventArgs e)
        {
            if (state != GameState.Running || snake == null) return;

            MoveSnake();

            // temporary speed effect handling
            if (temporarySpeedModifierTicks > 0)
            {
                temporarySpeedModifierTicks--;
                if (temporarySpeedModifierTicks == 0)
                {
                    // restore base interval according to level
                    gameTimer.Interval = currentInterval;
                }
            }

            // Allow direction changes for next tick after movement processed
            nextMoveIsDirectionLocked = false;

            GamePanel.Invalidate();
        }

        private void MoveSnake()
        {
            Point head = snake.First.Value;
            Point newHead = head;

            switch (direction)
            {
                case Direction.Up:
                    newHead = new Point(head.X, head.Y + 1);
                    break;
                case Direction.Down:
                    newHead = new Point(head.X, head.Y - 1);
                    break;
                case Direction.Left:
                    newHead = new Point(head.X - 1, head.Y);
                    break;
                case Direction.Right:
                    newHead = new Point(head.X + 1, head.Y);
                    break;
            }

            // Collision with walls
            if (newHead.X < 0 || newHead.X >= GridWidth || newHead.Y < 0 || newHead.Y >= GridHeight)
            {
                EndGame();
                return;
            }

            // Collision with self
            bool collidesWithBody = snake.Skip(0).Any(p => p.Equals(newHead));
            if (collidesWithBody)
            {
                EndGame();
                return;
            }

            // Add new head
            snake.AddFirst(newHead);

            // Did we eat food?
            if (newHead.Equals(food))
            {
                HandleFoodEat();
                PlaceFood();
            }
            else
            {
                // Remove tail unless we just grew (growingThisTick)
                if (!growingThisTick) snake.RemoveLast();
                growingThisTick = false;
            }
        }

        private void HandleFoodEat()
        {
            switch (currentFoodType)
            {
                case FoodType.Normal:
                    score += 10;
                    growingThisTick = true;
                    SystemSounds.Asterisk.Play();
                    break;
                case FoodType.FastFood:
                    score += 20;
                    growingThisTick = true;
                    // temporary speed up (reduce interval by 30% for 40 ticks)
                    gameTimer.Interval = Math.Max(30, (int)(gameTimer.Interval * 0.7));
                    temporarySpeedModifierTicks = 40;
                    SystemSounds.Beep.Play();
                    break;
                case FoodType.SlowFood:
                    score += 8;
                    growingThisTick = true;
                    // temporary slow down (increase interval by 30% for 40 ticks)
                    gameTimer.Interval = Math.Min(1000, (int)(gameTimer.Interval * 1.3));
                    temporarySpeedModifierTicks = 40;
                    SystemSounds.Exclamation.Play();
                    break;
                case FoodType.BonusFood:
                    score += 30;
                    // bonus doesn't necessarily grow snake (but we will grow)
                    growingThisTick = true;
                    // small immediate speed increase as reward
                    gameTimer.Interval = Math.Max(30, gameTimer.Interval - 20);
                    temporarySpeedModifierTicks = 20;
                    // distinct sound for bonus
                    SystemSounds.Asterisk.Play();
                    break;
            }

            lblScore.Text = $"Score: {score}";

            // Level up logic: increase level every 100 points (customize)
            int newLevel = 1 + (score / 100);
            // Since user wanted to start level at 3, ensure that baseline is considered:
            if (newLevel + 2 > level) // offset so that initial level=3 maps fine
            {
                level = newLevel + 2; // ensure growth keeps starting at 3
                // increase gameTimer base speed when level increases
                gameTimer.Interval = currentInterval;
                lblMessage.Text = $"Level up! Level: {level}";
                // optional small sound:
                SystemSounds.Asterisk.Play();
            }
        }
        #endregion

        #region Food placement
        private void PlaceFood()
        {
            // Build a list of available cells
            var occupied = new HashSet<Point>(snake);
            var freeCells = new List<Point>(GridWidth * GridHeight - occupied.Count);
            for (int x = 0; x < GridWidth; x++)
            {
                for (int y = 0; y < GridHeight; y++)
                {
                    var p = new Point(x, y);
                    if (!occupied.Contains(p)) freeCells.Add(p);
                }
            }

            if (freeCells.Count == 0)
            {
                // Filled entire board (win condition)
                EndGame();
                return;
            }

            var chosen = freeCells[rand.Next(freeCells.Count)];
            food = chosen;

            // Option B behavior: probability distribution (medium)
            // Normal: 50%, Fast: 20%, Slow: 20%, Bonus: 10%
            int r = rand.Next(100);
            if (r < 50) currentFoodType = FoodType.Normal;
            else if (r < 70) currentFoodType = FoodType.FastFood;
            else if (r < 90) currentFoodType = FoodType.SlowFood;
            else currentFoodType = FoodType.BonusFood;
        }
        #endregion

        #region Input handling
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (state == GameState.StartScreen && (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down ||
                                                   e.KeyCode == Keys.Left || e.KeyCode == Keys.Right))
            {
                StartGame();
                return;
            }

            if (state == GameState.GameOver && e.KeyCode == Keys.Enter)
            {
                StartGame();
                return;
            }

            if (state == GameState.Running && !nextMoveIsDirectionLocked)
            {
                Direction requested = direction;
                if (e.KeyCode == Keys.Up) requested = Direction.Up;
                else if (e.KeyCode == Keys.Down) requested = Direction.Down;
                else if (e.KeyCode == Keys.Left) requested = Direction.Left;
                else if (e.KeyCode == Keys.Right) requested = Direction.Right;
              

                // Prevent reversing direction immediately
                if (!IsOppositeDirection(direction, requested))
                {
                    direction = requested;
                    nextMoveIsDirectionLocked = true; // lock until next tick to avoid multiple changes in same tick
                }
            }
         
        }

        private static bool IsOppositeDirection(Direction a, Direction b)
        {
            return (a == Direction.Up && b == Direction.Down) ||
                   (a == Direction.Down && b == Direction.Up) ||
                   (a == Direction.Left && b == Direction.Right) ||
                   (a == Direction.Right && b == Direction.Left);
        }
        #endregion

        #region UI events
        private void btnStart_Click(object sender, EventArgs e)
        {
            // If game is running ? stop game
            if (state == GameState.Running)
            {
                EndGame();
                return;
            }

            // If paused ? restart fresh
            if (state == GameState.Paused)
            {
                EndGame();
                return;
            }

            // If game over or start screen ? start new game
            StartGame();
            this.Focus();
        }


        private void btnPause_Click(object sender, EventArgs e)
        {
            if (state == GameState.StartScreen)
            {
                // nothing to pause
                return;
            }
            PauseGame();
        }
        #endregion

        #region Rendering
        private void GamePanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            GamePanel.BackColor = backgroundColor;
            g.Clear(GamePanel.BackColor);

            // Draw grid background (optional subtle grid)
            using (var gridPen = new Pen(Color.FromArgb(40, 40, 40)))
            {
                for (int x = 0; x <= GridWidth; x++)
                {
                    g.DrawLine(gridPen, x * CellSize, 0, x * CellSize, GridHeight * CellSize);
                }
                for (int y = 0; y <= GridHeight; y++)
                {
                    g.DrawLine(gridPen, 0, y * CellSize, GridWidth * CellSize, y * CellSize);
                }
            }

            // Draw food using type-specific color
            if (food != Point.Empty)
            {
                Rectangle foodRect = new Rectangle(food.X * CellSize + 1, food.Y * CellSize + 1, CellSize - 2, CellSize - 2);
                Brush foodBrush = Brushes.Red;
                switch (currentFoodType)
                {
                    case FoodType.Normal:
                        foodBrush = Brushes.Red;
                        break;
                    case FoodType.FastFood:
                        foodBrush = Brushes.Orange;
                        break;
                    case FoodType.SlowFood:
                        foodBrush = Brushes.CornflowerBlue;
                        break;
                    case FoodType.BonusFood:
                        foodBrush = Brushes.Gold;
                        break;
                }
                g.FillEllipse(foodBrush, foodRect);
            }

            // Draw snake
            if (snake != null)
            {
                bool headDrawn = false;
                foreach (var p in snake)
                {
                    Rectangle r = new Rectangle(p.X * CellSize + 1, p.Y * CellSize + 1, CellSize - 2, CellSize - 2);
                    if (!headDrawn)
                    {
                        using (Brush b = new SolidBrush(snakeHeadColor))
                        {
                            g.FillRectangle(b, r);
                        }
                        headDrawn = true;
                    }
                    else
                    {
                        using (Brush b = new SolidBrush(snakeBodyColor))
                        {
                            g.FillRectangle(b, r);
                        }
                    }
                }
            }

            // If start screen or paused or game over, draw overlay text
            if (state == GameState.StartScreen)
            {
                DrawCenteredText(g, "Press Start to Begin\nArrow keys to move", GamePanel.ClientRectangle, 16, Brushes.White);
            }
            else if (state == GameState.Paused)
            {
                DrawCenteredText(g, "Paused", GamePanel.ClientRectangle, 24, Brushes.Yellow);
            }
            else if (state == GameState.GameOver)
            {
                DrawCenteredText(g, $"Game Over\nScore: {score}\nPress Start to Restart", GamePanel.ClientRectangle, 16, Brushes.Red);
            }
        }

        private void DrawCenteredText(Graphics g, string text, Rectangle bounds, int fontSize, Brush brush)
        {
            using (var sf = new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            using (var font = new Font("Segoe UI", fontSize, FontStyle.Bold))
            {
                g.DrawString(text, font, brush, bounds, sf);
            }
        }
        #endregion

        #region Settings panel handlers
        private void BtnChooseSnakeColor_Click(object sender, EventArgs e)
        {
            using (var cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    snakeHeadColor = cd.Color;
                    // set body a bit darker automatically
                    snakeBodyColor = ControlPaint.Dark(cd.Color);
                }
            }
        }

        private void BtnChooseBgColor_Click(object sender, EventArgs e)
        {
            using (var cd = new ColorDialog())
            {
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    backgroundColor = cd.Color;
                }
            }
        }

        private void BtnApplySettings_Click(object sender, EventArgs e)
        {
            GamePanel.Invalidate();
            panelSettings.Visible = false;
        }
        #endregion
    }

    // Direction enum
    enum Direction { Up, Down, Left, Right }
}
