﻿namespace SnakeGame
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        #region Controls
        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblHighScore;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.Button btnSettings;
       


        // Settings panel controls
        private System.Windows.Forms.Panel panelSettings;
        private System.Windows.Forms.Button btnChooseSnakeColor;
        private System.Windows.Forms.Button btnChooseBgColor;
        private System.Windows.Forms.Button btnApplySettings;

        // Difficulty selection
        private System.Windows.Forms.ComboBox cmbDifficulty;

        #endregion

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            GamePanel = new Panel();
            lblScore = new Label();
            lblHighScore = new Label();
            lblMessage = new Label();
            btnStart = new Button();
            btnPause = new Button();
            btnSettings = new Button();
            gameTimer = new System.Windows.Forms.Timer(components);
            panelSettings = new Panel();
            btnChooseSnakeColor = new Button();
            btnChooseBgColor = new Button();
            btnApplySettings = new Button();
            cmbDifficulty = new ComboBox();
            panelSettings.SuspendLayout();
            SuspendLayout();
            // 
            // GamePanel
            // 
            GamePanel.BackColor = Color.Black;
            GamePanel.BorderStyle = BorderStyle.FixedSingle;
            GamePanel.Location = new Point(12, 12);
            GamePanel.Name = "GamePanel";
            GamePanel.Size = new Size(400, 400);
            GamePanel.TabIndex = 0;
            // 
            // lblScore
            // 
            lblScore.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblScore.Location = new Point(430, 20);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(160, 24);
            lblScore.TabIndex = 1;
            lblScore.Text = "Score: 0";
            // 
            // lblHighScore
            // 
            lblHighScore.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblHighScore.Location = new Point(430, 50);
            lblHighScore.Name = "lblHighScore";
            lblHighScore.Size = new Size(160, 24);
            lblHighScore.TabIndex = 2;
            lblHighScore.Text = "High Score: 0";
            // 
            // lblMessage
            // 
            lblMessage.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblMessage.ForeColor = Color.Red;
            lblMessage.Location = new Point(12, 420);
            lblMessage.Name = "lblMessage";
            lblMessage.Size = new Size(400, 60);
            lblMessage.TabIndex = 3;
            lblMessage.Text = "Press Start to Begin";
            lblMessage.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnStart
            // 
            btnStart.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnStart.Location = new Point(430, 122);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(160, 36);
            btnStart.TabIndex = 4;
            btnStart.Text = "Start Game";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnPause
            // 
            btnPause.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnPause.Location = new Point(430, 174);
            btnPause.Name = "btnPause";
            btnPause.Size = new Size(160, 36);
            btnPause.TabIndex = 5;
            btnPause.Text = "Pause";
            btnPause.UseVisualStyleBackColor = true;
            btnPause.Click += btnPause_Click;
            // 
            // btnSettings
            // 
            btnSettings.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnSettings.Location = new Point(430, 288);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(160, 36);
            btnSettings.TabIndex = 8;
            btnSettings.Text = "Settings";
            btnSettings.UseVisualStyleBackColor = true;
            // 
            // gameTimer
            // 
            gameTimer.Interval = 120;
            gameTimer.Tick += gameTimer_Tick;
            // 
            // panelSettings
            // 
            panelSettings.BorderStyle = BorderStyle.FixedSingle;
            panelSettings.Controls.Add(btnChooseSnakeColor);
            panelSettings.Controls.Add(btnChooseBgColor);
            panelSettings.Controls.Add(btnApplySettings);
            panelSettings.Location = new Point(430, 330);
            panelSettings.Name = "panelSettings";
            panelSettings.Size = new Size(360, 140);
            panelSettings.TabIndex = 20;
            panelSettings.Visible = false;
            // 
            // btnChooseSnakeColor
            // 
            btnChooseSnakeColor.Font = new Font("Segoe UI", 9F);
            btnChooseSnakeColor.Location = new Point(10, 14);
            btnChooseSnakeColor.Name = "btnChooseSnakeColor";
            btnChooseSnakeColor.Size = new Size(130, 30);
            btnChooseSnakeColor.TabIndex = 21;
            btnChooseSnakeColor.Text = "Choose Snake Color";
            btnChooseSnakeColor.UseVisualStyleBackColor = true;
            // 
            // btnChooseBgColor
            // 
            btnChooseBgColor.Font = new Font("Segoe UI", 9F);
            btnChooseBgColor.Location = new Point(10, 50);
            btnChooseBgColor.Name = "btnChooseBgColor";
            btnChooseBgColor.Size = new Size(130, 30);
            btnChooseBgColor.TabIndex = 22;
            btnChooseBgColor.Text = "Choose BG Color";
            btnChooseBgColor.UseVisualStyleBackColor = true;
            // 
            // btnApplySettings
            // 
            btnApplySettings.Font = new Font("Segoe UI", 9F);
            btnApplySettings.Location = new Point(10, 90);
            btnApplySettings.Name = "btnApplySettings";
            btnApplySettings.Size = new Size(130, 30);
            btnApplySettings.TabIndex = 23;
            btnApplySettings.Text = "Apply & Close";
            btnApplySettings.UseVisualStyleBackColor = true;
            // 
            // cmbDifficulty
            // 
            cmbDifficulty.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbDifficulty.Font = new Font("Segoe UI", 10F);
            cmbDifficulty.Items.AddRange(new object[] { "Easy", "Medium", "Hard" });
            cmbDifficulty.Location = new Point(430, 257);
            cmbDifficulty.Name = "cmbDifficulty";
            cmbDifficulty.Size = new Size(160, 25);
            cmbDifficulty.TabIndex = 9;
            // 
            // Form1
            // 
            ClientSize = new Size(610, 500);
            Controls.Add(cmbDifficulty);
            Controls.Add(panelSettings);
            Controls.Add(btnSettings);
            Controls.Add(btnPause);
            Controls.Add(btnStart);
            Controls.Add(lblMessage);
            Controls.Add(lblHighScore);
            Controls.Add(lblScore);
            Controls.Add(GamePanel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            KeyPreview = true;
            MaximizeBox = false;
            Name = "Form1";
            Text = "Snake Game";
            KeyDown += Form1_KeyDown;
            panelSettings.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
    }
}
